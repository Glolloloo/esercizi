var pet_preferito = 'gatto';
console.log(pet_preferito);

var pet = 'gatto';
var Pet = 'cane';
var petPreferito = 'criceto';
var PetPreferito = 'coniglio';

var $pet = 'giraffa';
console.log($pet);
var _pet = 'leone';
console.log(_pet);
var _pet2 = 'pantera';
document.write(_pet2);

document.getElementById('animale').innerHTML += (pet);

window.alert('Sto studiando JS');

var numero = 12;
var numeroStringa = '12'