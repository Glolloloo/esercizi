alert('javascript');
window.alert('Sto studiando JS');