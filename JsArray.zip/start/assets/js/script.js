var stringa = 'Sto imparando JavaScript';
var stringa2 = 'JS'

document.getElementById('maiuscola').innerHTML = stringa.toUpperCase();
document.getElementById('minuscola').innerHTML = stringa.toLowerCase();
document.getElementById('strArray').innerHTML = stringa.split('');
document.getElementById('estraiCaratteri').innerHTML = stringa.charAt(2);
document.getElementById('concatena').innerHTML = stringa.concat(stringa2);
document.getElementById('estraiStringa').innerHTML = stringa.slice(4,9);


const array = ['Giovanni','Carla','Piero','Mirtilla'];

document.getElementById('array').innerHTML = array.toString();
document.getElementById('lunghezza').innerHTML = array.length;
document.getElementById('elemento').innerHTML = array[2];
document.getElementById('ultimo').innerHTML = array[3];

array.splice(2,1,'Massimo');
document.getElementById('modificato').innerHTML = array.toString();


const calcolaAnni = function (compleanno) {
    return 2022 - compleanno;
};

const anni = [2001,1990,1987,2018,2010];

const eta1 = calcolaAnni(anni[0]);
const eta2 = calcolaAnni(anni[1]);
const eta3 = calcolaAnni(anni[2]);
const eta4 = calcolaAnni(anni[3]);
const eta5 = calcolaAnni(anni[4]);

document.getElementById('eta1').innerHTML += `${eta1} anni`;
document.getElementById('eta2').innerHTML += `${eta2} anni`;
document.getElementById('eta3').innerHTML += `${eta3} anni`;
document.getElementById('eta4').innerHTML += `${eta4} anni`;
document.getElementById('eta5').innerHTML += `${eta5} anni`;

const array3 = [21,30,35,4,12];
document.getElementById('arrayEta').innerHTML += array3.toString();


const array4 = ['coniglio','gatto','cane','criceto'];
document.getElementById('intero').innerHTML += array4.toString();
array4.push('leone');
document.getElementById('aggiunto').innerHTML += array4.toString();
array4.pop();
document.getElementById('estratto').innerHTML += array4.toString();
document.getElementById('verifica1').innerHTML += array4.includes('coniglio');
document.getElementById('verifica2').innerHTML += array4.includes('lupo');