var name = 'Aldo';
let status = 'cliente';
const numero = '3.14';

document.getElementById('concatena').innerHTML = `${name}, ${status}, ${numero}.`;

var name = 'Aldo';
var stato = 'cliente';
var numero2 = '3.14';

document.getElementById('concatena2').innerHTML = `${name}, ${stato}, ${numero2}.`;




var nome1 = 'Mario'
document.getElementById('var').innerHTML = nome1;

{
    let nome1 = 'Carla'
    document.getElementById('let').innerHTML = nome1;
}

document.getElementById('final').innerHTML = nome1;


let nome2 = 'Mario'
document.getElementById('let2').innerHTML = nome2;

{
    let nome2 = 'Carla'
    document.getElementById('let3').innerHTML = nome2;
    document.getElementById('final2').innerHTML = nome2;
}




var valore = 15;
document.getElementById('iniziale').innerHTML += 15;

var primo = (valore + 15);
var primo1 = (valore + 15);
var primo2 = primo1 ++;
document.getElementById('valore1').innerHTML += `${primo}, ${primo1} `;

var secondo = (valore - 10);
var secondo1 = (valore - 10);
var secondo2 = secondo1 --;
document.getElementById('valore2').innerHTML += `${secondo}, ${secondo1} `;

document.getElementById('valore3').innerHTML += (valore * 3);

document.getElementById('valore4').innerHTML += (valore / 3);

document.getElementById('valore5').innerHTML += `${valore} è un numero`;