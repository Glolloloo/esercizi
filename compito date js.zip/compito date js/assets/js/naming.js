var today = new Date(2022, 9, 21, 17, 50, 24);
document.getElementById('data1').innerHTML =today;

var day = today.getDate();
document.getElementById('giorno').innerHTML = `Giorno: ${day}`;

var month1 = today.toLocaleString('default', {month: 'long'});
document.getElementById('mese').innerHTML = `Mese: ${month1}`;

var year = today.getFullYear();
var month = today.getMonth();
document.getElementById('giornata').innerHTML = `Oggi è il ${day} - ${month} - ${year}`;

document.getElementById('data').innerHTML += `${day}/${month1}/${year}`;

var time = today.toLocaleTimeString();
document.getElementById('ora').innerHTML = `Sono le ore: ${time}`;

var hour = today.getHours()

function salutare(){
    if(hour <= 12){
        document.getElementById('saluto').innerHTML = 'Buongiorno!';
    } else if (hour > 12){
        document.getElementById('saluto').innerHTML = 'Buonasera!';
    }
};
