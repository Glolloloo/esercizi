function corretta() {
    var a = '4';
    var b = '5';
    document.getElementById('corretta').innerHTML = `Succo con ${a} mele e ${b} arance`;
}

corretta()

function sbagliata() {
    var c = '6';
    var d;
    document.getElementById('sbagliata').innerHTML = `Succo con ${c} mele e ${d} arance`;
}

sbagliata()

function eta() {
    var eta = (2022 - 2001);
    document.getElementById('eta').innerHTML += ` ${eta} anni`;
}

eta()


 anna = () => {
    var anna = (2022 - 30);
    document.getElementById('persona1').innerHTML = `L\' anno di nascita di Anna è il ${anna}`;
}

anna()

 maria = () => {
    var maria = (2022 - 26);
    document.getElementById('persona2').innerHTML = `L\' anno di nascita di Maria è il ${maria}`;
}

maria()


function torta () {
        var mele = 9;
        var arance = 15;

     stampa(mele,arance)
    }
    
    torta()


function stampa (mele,arance) {
    document.getElementById('torta').innerHTML = `Torta con ${mele} fette di mele e  ${arance} fette di arancia`;
   }

   fette2()



var btn = document.getElementById('calcola');

btn.addEventListener('click', function () {
    let cibo = document.getElementById("cibo").value;
    let detersivi = document.getElementById("detersivi").value;
    let abiti = document.getElementById("abiti").value;
    let spesa = +cibo + +detersivi + +abiti;

    document.getElementById('totale').innerHTML += spesa;
});
